package com.brahalla.Cerberus.service;

public interface SecurityService {

  public Boolean hasProtectedAccess();

}
